
package net.mcreator.robertmod.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class GirmMobEffect extends MobEffect {
	public GirmMobEffect() {
		super(MobEffectCategory.HARMFUL, -13434880);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
