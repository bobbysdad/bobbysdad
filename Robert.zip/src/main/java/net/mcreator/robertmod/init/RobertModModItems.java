
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robertmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.robertmod.item.UnderworldItem;
import net.mcreator.robertmod.item.GrimstoneItem;
import net.mcreator.robertmod.item.GirmtoolItem;
import net.mcreator.robertmod.item.GirmswordItem;
import net.mcreator.robertmod.item.GirmpikItem;
import net.mcreator.robertmod.item.GirmingotItem;
import net.mcreator.robertmod.item.GirmarmorItem;
import net.mcreator.robertmod.RobertModMod;

public class RobertModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RobertModMod.MODID);
	public static final RegistryObject<Item> GRIMSTONE = REGISTRY.register("grimstone", () -> new GrimstoneItem());
	public static final RegistryObject<Item> GRIMORE = block(RobertModModBlocks.GRIMORE);
	public static final RegistryObject<Item> GIRMINGOT = REGISTRY.register("girmingot", () -> new GirmingotItem());
	public static final RegistryObject<Item> GIRMSWORD = REGISTRY.register("girmsword", () -> new GirmswordItem());
	public static final RegistryObject<Item> GRIMTNT = block(RobertModModBlocks.GRIMTNT);
	public static final RegistryObject<Item> GIRMPIK = REGISTRY.register("girmpik", () -> new GirmpikItem());
	public static final RegistryObject<Item> GIRMARMOR_HELMET = REGISTRY.register("girmarmor_helmet", () -> new GirmarmorItem.Helmet());
	public static final RegistryObject<Item> GIRMARMOR_CHESTPLATE = REGISTRY.register("girmarmor_chestplate", () -> new GirmarmorItem.Chestplate());
	public static final RegistryObject<Item> GIRMARMOR_LEGGINGS = REGISTRY.register("girmarmor_leggings", () -> new GirmarmorItem.Leggings());
	public static final RegistryObject<Item> GIRMARMOR_BOOTS = REGISTRY.register("girmarmor_boots", () -> new GirmarmorItem.Boots());
	public static final RegistryObject<Item> GIRMTOOL = REGISTRY.register("girmtool", () -> new GirmtoolItem());
	public static final RegistryObject<Item> GIRMPLANKS = block(RobertModModBlocks.GIRMPLANKS);
	public static final RegistryObject<Item> UNDERWORLD = REGISTRY.register("underworld", () -> new UnderworldItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
