
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robertmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.robertmod.potion.GirmMobEffect;
import net.mcreator.robertmod.RobertModMod;

public class RobertModModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, RobertModMod.MODID);
	public static final RegistryObject<MobEffect> GIRM = REGISTRY.register("girm", () -> new GirmMobEffect());
}
