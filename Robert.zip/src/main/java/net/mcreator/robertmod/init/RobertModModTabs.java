
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robertmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.robertmod.RobertModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RobertModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RobertModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(RobertModModBlocks.GIRMPLANKS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(RobertModModBlocks.GRIMTNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(RobertModModItems.GIRMSWORD.get());
			tabData.accept(RobertModModItems.GIRMARMOR_HELMET.get());
			tabData.accept(RobertModModItems.GIRMARMOR_CHESTPLATE.get());
			tabData.accept(RobertModModItems.GIRMARMOR_LEGGINGS.get());
			tabData.accept(RobertModModItems.GIRMARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(RobertModModItems.GRIMSTONE.get());
			tabData.accept(RobertModModItems.GIRMINGOT.get());
			tabData.accept(RobertModModItems.UNDERWORLD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(RobertModModBlocks.GRIMORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RobertModModItems.GIRMPIK.get());
			tabData.accept(RobertModModItems.GIRMTOOL.get());
		}
	}
}
