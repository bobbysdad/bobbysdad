
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robertmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.robertmod.enchantment.GirmlightEnchantment;
import net.mcreator.robertmod.RobertModMod;

public class RobertModModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, RobertModMod.MODID);
	public static final RegistryObject<Enchantment> GIRMLIGHT = REGISTRY.register("girmlight", () -> new GirmlightEnchantment());
}
