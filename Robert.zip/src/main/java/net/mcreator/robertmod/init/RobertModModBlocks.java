
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robertmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.robertmod.block.UnderworldPortalBlock;
import net.mcreator.robertmod.block.GrimtntBlock;
import net.mcreator.robertmod.block.GrimoreBlock;
import net.mcreator.robertmod.block.GirmplanksBlock;
import net.mcreator.robertmod.RobertModMod;

public class RobertModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RobertModMod.MODID);
	public static final RegistryObject<Block> GRIMORE = REGISTRY.register("grimore", () -> new GrimoreBlock());
	public static final RegistryObject<Block> GRIMTNT = REGISTRY.register("grimtnt", () -> new GrimtntBlock());
	public static final RegistryObject<Block> GIRMPLANKS = REGISTRY.register("girmplanks", () -> new GirmplanksBlock());
	public static final RegistryObject<Block> UNDERWORLD_PORTAL = REGISTRY.register("underworld_portal", () -> new UnderworldPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
